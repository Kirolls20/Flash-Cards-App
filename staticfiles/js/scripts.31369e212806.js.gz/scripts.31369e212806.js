document.getElementById('add-btn').addEventListener('click', function() {
   document.querySelector('.bg-form').style.display = 'flex';
});
document.getElementById('close-btn').addEventListener('click', function() {
   document.querySelector('.bg-form').style.display = 'none';
});


